#include <string>
#include <vector>

namespace X3DSceneGraph {

	bool loadHeights(std::string filename, std::vector<float> *plane);

}

namespace SG = X3DSceneGraph;
