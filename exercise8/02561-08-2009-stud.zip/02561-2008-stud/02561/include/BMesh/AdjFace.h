#ifndef __ADJFACE_H__
#define __ADJFACE_H__

namespace BMesh
{
	class AdjFace {
	public:
		unsigned int f[3];
		AdjFace();
	};
}
#endif

